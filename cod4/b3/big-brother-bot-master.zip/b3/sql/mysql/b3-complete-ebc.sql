-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 09, 2024 at 10:26 PM
-- Server version: 10.6.12-MariaDB-0ubuntu0.22.04.1
-- PHP Version: 8.1.2-1ubuntu2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `b3`
--

-- --------------------------------------------------------

--
-- Table structure for table `aliases`
--

CREATE TABLE `aliases` (
  `id` int(10) UNSIGNED NOT NULL,
  `num_used` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `alias` varchar(32) NOT NULL DEFAULT '',
  `client_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `time_add` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `time_edit` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip` varchar(16) NOT NULL DEFAULT '',
  `connections` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `guid` varchar(36) NOT NULL DEFAULT '',
  `pbid` varchar(32) NOT NULL DEFAULT '',
  `name` varchar(32) NOT NULL DEFAULT '',
  `auto_login` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `mask_level` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `group_bits` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `greeting` varchar(128) NOT NULL DEFAULT '',
  `time_add` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `time_edit` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `password` varchar(32) DEFAULT NULL,
  `login` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `ip`, `connections`, `guid`, `pbid`, `name`, `auto_login`, `mask_level`, `group_bits`, `greeting`, `time_add`, `time_edit`, `password`, `login`) VALUES
(1, '', 4, 'WORLD', 'WORLD', 'World', 1, 0, 0, '', 1704832928, 1704833210, '', ''),

-- --------------------------------------------------------

--
-- Table structure for table `cmdgrants`
--

CREATE TABLE `cmdgrants` (
  `id` int(11) NOT NULL,
  `commands` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `current_clients`
--

CREATE TABLE `current_clients` (
  `id` int(3) NOT NULL,
  `Updated` varchar(25) NOT NULL,
  `Name` varchar(32) NOT NULL,
  `Level` int(10) NOT NULL,
  `DBID` int(10) NOT NULL,
  `CID` varchar(32) NOT NULL,
  `Joined` varchar(25) NOT NULL,
  `Connections` int(11) NOT NULL,
  `State` int(1) NOT NULL,
  `Score` int(10) NOT NULL,
  `IP` varchar(16) NOT NULL,
  `GUID` varchar(36) NOT NULL,
  `PBID` varchar(32) NOT NULL,
  `Team` int(1) NOT NULL,
  `ColorName` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `current_svars`
--

CREATE TABLE `current_svars` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `current_svars`
--

INSERT INTO `current_svars` (`id`, `name`, `value`) VALUES
(1, 'Ip', '142.132.220.66'),
(2, 'Port', '28960'),
(3, 'Name', 'cod4'),
(4, 'Type', 'sr'),
(5, 'Map', 'mp_crash'),
(6, 'TimeLimit', ''),
(7, 'FragLimit', ''),
(8, 'CaptureLimit', ''),
(9, 'Rounds', '20'),
(10, 'RoundTime', '100'),
(11, 'MapTime', '2351'),
(12, 'OnlinePlayers', '0'),
(13, 'lastupdate', '1704835561'),
(14, 'protocol', '21'),
(15, 'gameName', 'Call of Duty 4'),
(16, 'sv_privateClients', '0'),
(17, 'sv_maxRate', '25000'),
(18, '_mapTimeStart', '1704833210'),
(19, '_mapName', 'mp_crash'),
(20, 'sv_disableClientConsole', '0'),
(21, 'uptime', '38 minutes'),
(22, 'console', '<b3.parsers.cod4x.Cod4XParser object at 0x7f4f4b7530d0>'),
(23, 'fs_game', 'mods/try_me'),
(24, 'version', 'CoD4 X - linux-i386-custom build 1203 Jan  9 2024'),
(25, 'build', '1203'),
(26, 'branch', 'master'),
(27, 'sv_pure', '1'),
(28, '_roundTimeStart', '1704835461'),
(29, '_CoD4 X Site', 'http://cod4x.ovh'),
(30, 'revision', '6b9a9430c0f2fb15a9838b9ea18d2d538e02cbe8'),
(31, 'sv_voice', '0'),
(32, 'modName', 'mods/try_me'),
(33, 'sv_minPing', '0'),
(34, 'fs_homepath', '/home/tcagame/r4g3/1'),
(35, 'sv_maxclients', '24'),
(36, 'sv_hostname', 'COD4 Server - Round: 18/20'),
(37, 'sv_floodprotect', '4'),
(38, 'fs_basepath', '/home/tcagame/r4g3/1'),
(39, 'g_compassShowEnemies', '0'),
(40, 'g_mapStartTime', 'Tue Jan  9 21:46:10 2024'),
(41, 'gameType', 'sr'),
(42, '_Admin', 'admin'),
(43, 'shortversion', '-'),
(44, 'g_logTimeStampInSeconds', '0'),
(45, 'sv_maxPing', '0');

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `data_key` varchar(255) NOT NULL,
  `data_value` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`data_key`, `data_value`) VALUES
('last_map', 'mp_crash');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) NOT NULL DEFAULT '',
  `keyword` varchar(32) NOT NULL DEFAULT '',
  `level` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `time_edit` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `time_add` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `keyword`, `level`, `time_edit`, `time_add`) VALUES
(128, 'Super Admin', 'superadmin', 100, 0, 1704832927),
(64, 'Senior Admin', 'senioradmin', 80, 0, 1704832927),
(32, 'Full Admin', 'fulladmin', 60, 0, 1704832927),
(16, 'Admin', 'admin', 40, 0, 1704832927),
(8, 'Moderator', 'mod', 20, 0, 1704832927),
(2, 'Regular', 'reg', 2, 0, 1704832927),
(1, 'User', 'user', 1, 0, 1704832927),
(0, 'Guest', 'guest', 0, 0, 1704832927);

-- --------------------------------------------------------

--
-- Table structure for table `ipaliases`
--

CREATE TABLE `ipaliases` (
  `id` int(10) UNSIGNED NOT NULL,
  `num_used` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ip` varchar(16) NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `time_add` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `time_edit` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nicks`
--

CREATE TABLE `nicks` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `penalties`
--

CREATE TABLE `penalties` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` enum('Ban','TempBan','Kick','Warning','Notice') NOT NULL DEFAULT 'Ban',
  `client_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `admin_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `duration` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `inactive` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `keyword` varchar(16) NOT NULL DEFAULT '',
  `reason` varchar(255) NOT NULL DEFAULT '',
  `data` varchar(255) NOT NULL DEFAULT '',
  `time_add` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `time_edit` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `time_expire` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `player_core`
--

CREATE TABLE `player_core` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `guid` varchar(32) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `status` varchar(32) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'default',
  `style` varchar(32) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'default',
  `winterprestige` int(11) NOT NULL DEFAULT 0,
  `summerprestige` int(11) NOT NULL DEFAULT 0,
  `prestige` int(11) NOT NULL DEFAULT 0,
  `backup_pr` int(11) NOT NULL DEFAULT 0,
  `season` varchar(32) DEFAULT 'null',
  `award_tier` int(11) NOT NULL DEFAULT 0,
  `donation_tier` int(11) NOT NULL DEFAULT 0,
  `donation_date` varchar(16) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `player_core`
--

INSERT INTO `player_core` (`id`, `name`, `guid`, `status`, `style`, `winterprestige`, `summerprestige`, `prestige`, `backup_pr`, `season`, `award_tier`, `donation_tier`, `donation_date`) VALUES
(1, 'Wz-Cro', '2310346614371972278', 'default', 'default', 0, 0, 0, 0, 'summer', 0, 0, '0');

-- --------------------------------------------------------

--
-- Table structure for table `prestige_log`
--

CREATE TABLE `prestige_log` (
  `id` int(11) NOT NULL,
  `guid` varchar(19) NOT NULL,
  `name` varchar(40) NOT NULL,
  `prestige` int(11) NOT NULL,
  `time` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aliases`
--
ALTER TABLE `aliases`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `alias` (`alias`,`client_id`),
  ADD KEY `client_id` (`client_id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `guid` (`guid`),
  ADD KEY `group_bits` (`group_bits`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `cmdgrants`
--
ALTER TABLE `cmdgrants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `current_clients`
--
ALTER TABLE `current_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `current_svars`
--
ALTER TABLE `current_svars`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`data_key`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `keyword` (`keyword`),
  ADD KEY `level` (`level`);

--
-- Indexes for table `ipaliases`
--
ALTER TABLE `ipaliases`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ipalias` (`ip`,`client_id`),
  ADD KEY `client_id` (`client_id`);

--
-- Indexes for table `nicks`
--
ALTER TABLE `nicks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `client_id` (`client_id`);

--
-- Indexes for table `penalties`
--
ALTER TABLE `penalties`
  ADD PRIMARY KEY (`id`),
  ADD KEY `keyword` (`keyword`),
  ADD KEY `type` (`type`),
  ADD KEY `time_expire` (`time_expire`),
  ADD KEY `time_add` (`time_add`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `inactive` (`inactive`),
  ADD KEY `client_id` (`client_id`);

--
-- Indexes for table `player_core`
--
ALTER TABLE `player_core`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `guid` (`guid`);

--
-- Indexes for table `prestige_log`
--
ALTER TABLE `prestige_log`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aliases`
--
ALTER TABLE `aliases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `current_clients`
--
ALTER TABLE `current_clients`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `current_svars`
--
ALTER TABLE `current_svars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `ipaliases`
--
ALTER TABLE `ipaliases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `nicks`
--
ALTER TABLE `nicks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `penalties`
--
ALTER TABLE `penalties`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `player_core`
--
ALTER TABLE `player_core`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `prestige_log`
--
ALTER TABLE `prestige_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
